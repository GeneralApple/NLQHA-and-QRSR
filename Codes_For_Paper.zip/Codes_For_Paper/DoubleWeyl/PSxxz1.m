clear all;
%% Grid and parameters
tic
rk = 51;
thk = 51;
phk = 101;

sz =300;
s = 1;
a = 0.05;
dim = [1.5 3 6];
for di =1:3
 
D = dim(di);
sz = fix(100*4*D/3);
G = 0.05;
Tm = 0.0001;
reg = 0.0001;

rm = linspace(0,100,rk);
th = linspace(0,pi,thk);
ph = linspace(0,2*pi,phk);

dr = rm(2) - rm(1);
dth = th(2) - th(1);
dph = ph(2) - ph(1);

[R,T] = meshgrid(rm,th);



J = 0 * T;
Fp = 0 * T;
dH = 0 * T;

%% Syper long Heaviside calculations

 
%% Conductivity component
tic

omega = linspace(0,2*D+1,sz);
smol1 = zeros(1,sz);
smol2 = zeros(1,sz);
smnw1 = zeros(1,sz);


sc1 = zeros(1,sz);
sc2 = zeros(1,sz);
sc3 = zeros(1,sz);


smJ = zeros(1,sz);
smBD = zeros(1,sz);
smI11 = zeros(1,sz);
smI11v2 = zeros(1,sz);
smI2 = zeros(1,sz);
smI2v2 = zeros(1,sz);
smDW = zeros(1,sz);
for wi = 1 : sz
w = omega(wi);
mu = 0;
wext = mu*omega(wi);

for j = 1 :thk
    for k = 1 : phk
        t = th(j);
        p = ph(k);
        ct = sin(t)*cos(p);

        f1 = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w-2*r+1i*G).*(wext-w+2*r+1i*G).*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        f2 = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w-2*r+1i*G).*(wext-2*r+1i*G).^2.*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        f3 = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w-2*r+1i*G).*(wext-2*r+1i*G).*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        

        f1p = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w+2*r+1i*G).*(wext-w-2*r+1i*G).*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        f2p = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w+2*r+1i*G).*(wext+2*r+1i*G).^2.*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        f3p = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w+2*r+1i*G).*(wext+2*r+1i*G).*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        

        f2w = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((wext-w-2*r+1i*G).*(wext-2*r+1i*G).^2.*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        f3w = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((wext-w-2*r+1i*G).*(wext-2*r+1i*G).*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        

        f2pw = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((wext-w+2*r+1i*G).*(wext+2*r+1i*G).^2.*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        f3pw = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((wext-w+2*r+1i*G).*(wext+2*r+1i*G).*(reg+abs(sqrt(1+r*sin(t)*sin(p)/D))));
        
        fBD =  1/((w+1i*G)*((wext+1i*G)*(1+a*ct)-2)*(1+a*ct)*sqrt(1+sin(t)*sin(p)/(D*(1+a*ct))));
        fBDp =  1/((w+1i*G)*((wext+1i*G)*(1+a*ct)+2)*(1+a*ct)*sqrt(1+sin(t)*sin(p)/(D*(1+a*ct))));
        fBDw =  1/((wext-w+1i*G)*((wext+1i*G)*(1+a*ct)-2)*(1+a*ct)*sqrt(1+sin(t)*sin(p)/(D*(1+a*ct))));
        fBDpw =  1/((wext-w+1i*G)*((wext+1i*G)*(1+a*ct)+2)*(1+a*ct)*sqrt(1+sin(t)*sin(p)/(D*(1+a*ct))));
        

%Jerk
    U = cos(th(j))*(cos(th(j))^2 * cos(ph(k))^2+sin(ph(k))^2)/2;
    Oa = (wext+2*1i*G)*U /((wext+1i*G)*(2*pi)^3);
    Oac = (wext+2*1i*G)*conj(U) /((wext+1i*G)*(2*pi)^3);
    smJ(wi) = smJ(wi) +dth*dph*sin(th(j))*(Oa*integral(f1,0,Inf)+Oac*integral(f1p,0,Inf));
%Interband 1 term 1

    
    Oa = 1i*sin(th(j))^2* cos(ph(k))*(1i*cos(th(j))*cos(ph(k))+sin(ph(k)))/2;
    smI11(wi) = smI11(wi) + (wext+1i*G)*dph*dth*sin(th(j))*( integral(f2,0,Inf)*Oa + integral(f2p,0,Inf)*conj(Oa) );
    smI11(wi) = smI11(wi) + (wext+1i*G)*dph*dth*sin(th(j))*( integral(f2w,0,Inf)*Oa + integral(f2pw,0,Inf)*conj(Oa) );

%Interband 1 term 1v2

    
    Oa = (2*cos(th(j))^3+cos(th(j))*(-3+cos(2*th(j)))*cos(2*ph(k))+2*1i*sin(2*ph(k)))/4;
    smI2v2(wi) = smI2v2(wi) - dth*dph*sin(th(j))*( integral(f3,0,Inf)*Oa + integral(f3p,0,Inf)*conj(Oa) );
    smI2v2(wi) = smI2v2(wi) - dth*dph*sin(th(j))*( integral(f3w,0,Inf)*Oa + integral(f3pw,0,Inf)*conj(Oa) );
    
    
%Interband 2 term 1
    Oa = (cos(th(j))^3-cos(th(j))*cos(2*ph(k))*sin(th(j))^2+1i*cos(ph(k))*sin(th(j))^2 *sin(ph(k)))/2;
    smI2(wi) = smI2(wi) - dth*dph*sin(th(j))*( integral(f3,0,Inf)*Oa + integral(f3p,0,Inf)*conj(Oa) );
    smI2(wi) = smI2(wi) - dth*dph*sin(th(j))*( integral(f3w,0,Inf)*Oa + integral(f3pw,0,Inf)*conj(Oa) );
%Berry Dipole

     z = cos(th(j));
     U = 1i*sin(th(j))^2*(a + cos(ph(k)) * sin(th(j)))*(1i*cos(th(j))*cos(ph(k))+sin(ph(k))) /2 ;
     smBD(wi) = smBD(wi) + dth *dph * ( fBD * U   + fBDp * conj(U) );        
     smBD(wi) = smBD(wi) + dth *dph* ( fBDw * U   + fBDpw * conj(U) ); 
   
     
    end 
end

end

%plot(omega,real(sc1),omega,real(sc2),omega,real(sc3));
plot(omega,real(smBD),omega,real(smJ),omega,real(smI11+smI2)/((2*pi)^3));
legend('BD','Shift current','interband')
title('Re$\sigma^{\mathbf{S}}_{\{xx\}z}$','interpreter','latex')
%figure
%plot(omega,imag(smBD),omega,imag(smJ),omega,imag(smI11+smI2)/((2*pi)^3));
%legend('BD','Shift current','interband')
%title('Im$\sigma^{\mathbf{S}}_{xyz}$','interpreter','latex')
strings = ['xxzd' num2str(di) '.mat']; 
save(strings,'omega','smBD','smJ','smI11','smI2')
end
toc