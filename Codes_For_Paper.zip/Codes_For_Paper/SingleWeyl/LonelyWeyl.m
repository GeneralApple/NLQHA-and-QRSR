clear all;
%% Grid and parameters
tic
rk = 51;
thk = 201;

sz = 400;
s = 1;
a = 0.2;
D = 5;
G = 0.05;
Tm = 0.0001;
regular = 0.0001;

rm = linspace(0,100,rk);
th = linspace(0,pi,thk);


dr = rm(2) - rm(1);
dth = th(2) - th(1);


[R,T] = meshgrid(rm,th);



J = 0 * T;
Fp = 0 * T;
dH = 0 * T;

%% Syper long Heaviside calculations

 
%% Conductivity component
tic

omega = linspace(0,5,sz);
smol1 = zeros(1,sz);
smol2 = zeros(1,sz);
smnw1 = zeros(1,sz);


sc1 = zeros(1,sz);
sc2 = zeros(1,sz);
sc3 = zeros(1,sz);


smJ = zeros(1,sz);
smBD = zeros(1,sz);
smI11 = zeros(1,sz);
smI2 = zeros(1,sz);
smDW = zeros(1,sz);
for wi = 1 : sz
w = omega(wi);
mu = 0;
wext = mu*omega(wi);

%         fBDt = @(r,t) sin(t).^3.*(r.*sech((1 - r.*(a*cos(t) + s))/Tm).^2/Tm)./((w+1i*G).*(wext-2*r+1i*G));
%         fBDpt = @(r,t) sin(t).^3.*(r.*sech((1 - r.*(a*cos(t) + s))/Tm).^2/Tm)./((w+1i*G).*(wext+2*r+1i*G));
%         fBDwt = @(r,t) sin(t).*cos(t).*(a+cos(t)).*(r.*sech((1 - r.*(a*cos(t) + s))/Tm).^2/Tm)./((wext-w+1i*G).*(wext-2*r+1i*G));
%         fBDpwt = @(r,t) sin(t).*cos(t).*(a+cos(t)).*(r.*sech((1 - r.*(a*cos(t) + s))/Tm).^2/Tm)./((wext-w+1i*G).*(wext+2*r+1i*G));


for j = 1 :thk
        ct = cos(th(j));

        f1 = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w-2*r+1i*G).*(wext-w+2*r+1i*G));
        f2 = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w-2*r+1i*G).*(wext-2*r+1i*G).^2);
        f3 = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w-2*r+1i*G).*(wext-2*r+1i*G));
        

        f1p = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w+2*r+1i*G).*(wext-w-2*r+1i*G));
        f2p = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w+2*r+1i*G).*(wext+2*r+1i*G).^2);
        f3p = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((w+2*r+1i*G).*(wext+2*r+1i*G));
        

        f2w = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((wext-w-2*r+1i*G).*(wext-2*r+1i*G).^2);
        %f3w = @(r) (tanh((1 - r*(a*ct + s))/Tm)-1)./((wext-w-2*r+1i*G).*(wext-2*r+1i*G));
        

        f2pw = @(r) ((tanh((1 - r*(a*ct + s))/Tm)+1)/2-1)./((wext-w+2*r+1i*G).*(wext+2*r+1i*G).^2);
        %f3pw = @(r) (tanh((1 - r*(a*ct + s))/Tm)-1)./((wext-w+2*r+1i*G).*(wext+2*r+1i*G));
        
%         fBD = @(r) (r.*sech((1 - r*(a*ct + s))/Tm).^2/(2*Tm))./((w+1i*G).*(wext-2*r+1i*G));
%         fBDp = @(r) (r.*sech((1 - r*(a*ct + s))/Tm).^2/(2*Tm))./((w+1i*G).*(wext+2*r+1i*G));
%         fBDw = @(r) (r.*sech((1 - r*(a*ct + s))/Tm).^2/(2*Tm))./((wext-w+1i*G).*(wext-2*r+1i*G));
%         fBDpw = @(r) (r.*sech((1 - r*(a*ct + s))/Tm).^2/(2*Tm))./((wext-w+1i*G).*(wext+2*r+1i*G));
        fBD =  1/((w+1i*G)*((wext+1i*G)*(1+a*ct)-2)*(1+a*ct));

        fBDp =  1/((w+1i*G)*((wext+1i*G)*(1+a*ct)+2)*(1+a*ct));

        fBDw =  1/((wext-w+1i*G)*((wext+1i*G)*(1+a*ct)-2)*(1+a*ct));

        fBDpw =  1/((wext-w+1i*G)*((wext+1i*G)*(1+a*ct)+2)*(1+a*ct));
        

%Jerk
    U = -1i*pi*sin(th(j))^2/4;
    Oa = (wext+2*1i*G)*U /((wext+1i*G)*(2*pi)^3);
    smJ(wi) = smJ(wi) +dth*Oa*sin(th(j))*(integral(f1,0,Inf)-integral(f1p,0,Inf));
%Interband 1 term 1
    %Oa = 1i*pi*cos(th(j))^2 /2;
    %smI11(wi) = smI11(wi) + (wext+1i*G)*dth*sin(th(j))*( integral(f2,0,Inf)*Oa + integral(f2p,0,Inf)*conj(Oa) );
    
    Oa = 1i*pi*cos(th(j))^2 /2;
    smI11(wi) = smI11(wi) + (wext+1i*G)*dth*sin(th(j))*( integral(f2,0,Inf)*Oa - integral(f2p,0,Inf)*(Oa) );
    Oa = -1i*pi*sin(th(j))^2 /4;
    smI11(wi) = smI11(wi) + (wext+1i*G)*dth*sin(th(j))*( integral(f2w,0,Inf)*Oa - integral(f2pw,0,Inf)*(Oa) );
    
%Interband 1 term 2

%Interband 2 term 1
    Oa = -1i*(1+3*cos(2*th(j)))/8;
    smI2(wi) = smI2(wi) + dth*sin(th(j))*( integral(f3,0,Inf)*Oa - integral(f3p,0,Inf)*(Oa) );
    
%Berry Dipole

     z = cos(th(j));
     U = -1i*pi*sin(th(j))^3/(4*(2*pi)^3) ;
     smBD(wi) = smBD(wi) + dth * ( fBD * U   + fBDp * conj(U) );        
     U = pi*1i*cos(th(j))*sin(th(j))*(a+cos(th(j)))/(2*(2*pi)^3);      
     smBD(wi) = smBD(wi) + dth * ( fBDw * U   + fBDpw * conj(U) );      
   
     
    
end

%      U = -1i*pi/4 ;
%      smBD(wi) = smBD(wi) +  ( integral2(fBDt,0,2,0,pi) * U   - integral2(fBDpt,0,2,0,pi) * U );        
%      U = pi*1i/2;      
%      smBD(wi) = smBD(wi) +  ( integral2(fBDwt,0,2,0,pi) * U   - integral2(fBDpwt,0,2,0,pi) * U );
end

%plot(omega,real(sc1),omega,real(sc2),omega,real(sc3));
plot(omega,real(smBD),omega,real(smJ),omega,real(smI11)/((2*pi)^3));
legend('BD','Shift current','Interband')
title('Re$\sigma^{\mathbf{S}}_{\{xy\}z}$','interpreter','latex')
figure
plot(omega,imag(smBD),omega,imag(smJ),omega,imag(smI11)/((2*pi)^3));
legend('BD','Shift current','Interband')
title('Im$\sigma^{\mathbf{S}}_{\{xy\}z}$','interpreter','latex')
save('SingleWeylRes1.mat','omega','smBD','smJ','smI11','a','G')
toc